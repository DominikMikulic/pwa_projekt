<!DOCTYPE html>
<html>

  <head>

    <meta charset="utf-8">

    <link rel="stylesheet" media="screen" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  </head>
    <body>
        <header>
        
            <nav>
                <img class="navslika" src="nav1.jpg" alt="">
                <ul>    
                <li> <a href="index.php" class="">Početna</a> </li> 
                    <li> <a href="kategorija.php?id=sport" class="">Sport</a> </li> 
                    <li><a href="kategorija.php?id=kultura" class="">Kultura</a> </li> 
                    <li> <a href="ako_je_admin.php" class="">Administracija</a> </li> 
                    <li><a href="unos.php">Unos</a></li>
                </ul>
                </nav>         
        </header>


     

        <?php 
        include 'connect.php'; 
        define('UPLPATH', 'img/'); 
        ?>
        
        
        <?php 
        if($_GET['id']=='kultura'){
          echo '<section class="kultura">'; 
        $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='kultura'"; 
        $result = mysqli_query($dbc, $query); 
        $i=0; 
        echo '<div id="main">';
        echo '<div class="blog">';
        echo '<h3>Kultura</h3>';
        echo '</article>'; 
        echo '</div></div>'; 
       


        
        while($row = mysqli_fetch_array($result)) { 
            echo '<div id="main">';
            echo '<div class="blog">';
            echo '<article class="first">';
            echo '<article>'; 
            echo'<div class="article">'; 
            echo '<div class="sport_img">'; 
            echo '<img src="' . UPLPATH . $row['slika'] . '"'; 
            echo '</div>'; 
            echo '<div class="media_body">'; 
            echo '<h4 class="title"><br>'; 
            echo '<a href="clanak.php?id='.$row['id'].'">'; 
            echo $row['naslov']; 
            echo '</a></h4>'; 
            echo '<p>' . $row['datum'] . '</p>'; 
            echo '</div></div>'; 
            echo '</article>'; 
            echo '</article>'; 
            echo '</div></div>'; 

           

            }
            echo '</section>';
          }
          else{
            echo '<section class="sport">'; 
      
        $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='sport'"; 
        $result = mysqli_query($dbc, $query); 
        $i=0;
        echo '<div id="main">';
        echo '<div class="about">';
        echo '<h3>Sport</h3>';
        echo '</article>'; 
        echo '</div></div>'; 

        while($row = mysqli_fetch_array($result)) { 
            echo '<div id="main">';
            echo '<div class="blog">';
            echo '<article class="first">';
            echo '<article>'; 
            echo'<div class="article">'; 
            echo '<div class="sport_img">'; 
            echo '<img src="' . UPLPATH . $row['slika'] . '"'; 
            echo '</div>'; 
            echo '<div class="media_body">'; 
            echo '<h4 class="title"><br>'; 
            echo '<a href="clanak.php?id='.$row['id'].'">'; 
            echo $row['naslov']; 
            echo '</a></h4>';
            echo '<p>' . $row['datum'] . '</p>';  
            echo '</div></div>'; 
            echo '</article>'; 
            echo '</article>'; 
            echo '</div></div>'; 
            
            }
            echo '</section>';

          }
            ?> 
            

            


        <footer>
        
        </footer>
    </body>
</html>