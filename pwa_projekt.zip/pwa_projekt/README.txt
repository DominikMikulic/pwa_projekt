u bazi su tri korisnika:

username: marko
password: 123
administrator

username:ante
password:12345
nije administrator

username:david
password:1111
nije administrator

Ako dođe do nekih problema slobodno pitajte: dmikulic@tvz.hr