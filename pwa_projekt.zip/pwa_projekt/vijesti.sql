-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2021 at 11:56 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vijesti`
--
CREATE DATABASE IF NOT EXISTS `vijesti` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `vijesti`;

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `ime` varchar(32) NOT NULL,
  `prezime` varchar(32) NOT NULL,
  `korisnicko_ime` varchar(32) NOT NULL,
  `lozinka` varchar(255) NOT NULL,
  `razina` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `razina`) VALUES
(4, '', '', '', '$2y$10$B92DbVu3EfXijJ6zfN.rqu6LZZn3E7cZXugJPl/Hl/swko2tu04Wq', 0),
(5, 'marko', 'marulic', 'marko', '$2y$10$Zn7jwo9SYXhUihTHe3B1Qe5BytIU/sxBB3N.0B6VKM4uGwAy5xD82', 1),
(6, 'ante', 'antic', 'ante', '$2y$10$bGUlO0lW0SD7DkqNzG1dpO/4LAAEeyG9aymaKDeojtWOJ8WKGIGqe', 0),
(7, 'david', 'davidovic', 'david', '$2y$10$UWYImMvupfCNKFAlUYKnqusSaBO82n3wm9fCEwbj9tSwJ.AfqzMdS', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `datum` varchar(32) NOT NULL,
  `naslov` varchar(64) NOT NULL,
  `sazetak` text NOT NULL,
  `tekst` text NOT NULL,
  `slika` varchar(64) NOT NULL,
  `kategorija` varchar(64) NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(64, '13.06.2021.', 'Ovo je kultura', 'Ovo je kulturaOvo je kulturaOvo je kultura', 'Ovo je kulturaOvo je kulturaOvo je kulturaOvo je kulturaOvo je kulturaOvo je kultura', 'slika1.jpg', 'kultura', 1),
(65, '13.06.2021.', 'Ovo je kultura', 'Ovo je kulturaOvo je kulturaOvo je kultura', 'Ovo je kulturaOvo je kulturaOvo je kulturaOvo je kulturaOvo je kulturaOvo je kultura', 'slika1.jpg', 'kultura', 0),
(66, '13.06.2021.', 'Ovo je kultura1', 'Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1', 'Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1', 'slika2.jpg', 'kultura', 0),
(67, '13.06.2021.', 'Ovo je kultura1', 'Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1', 'Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1Ovo je kultura1', 'slika3.jpg', 'kultura', 1),
(68, '13.06.2021.', 'Ovo je kultura3', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'slika4.jpg', 'kultura', 0),
(69, '13.06.2021.', 'Ovo je kultura3', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'slika4.jpg', 'kultura', 1),
(70, '13.06.2021.', 'Ovo je kultura4', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'slika5.jpg', 'kultura', 1),
(71, '13.06.2021.', 'Ovo je kultura4', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'slika5.jpg', 'kultura', 0),
(72, '13.06.2021.', 'Ovo je kultura4', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3Ovo je kultura3', 'slika5.jpg', 'kultura', 0),
(73, '13.06.2021.', 'Ovo je sport', 'Ovo je sportOvo je sportOvo je sportOvo je sport', 'Ovo je sportOvo je sportOvo je sportOvo je sport', 'slika6.jpg', 'sport', 1),
(74, '13.06.2021.', 'Ovo je sport', 'Ovo je sportOvo je sportOvo je sportOvo je sport', 'Ovo je sportOvo je sportOvo je sportOvo je sport', 'slika6.jpg', 'sport', 0),
(75, '13.06.2021.', 'Ovo je sport2', 'Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2', 'Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2', 'slika5.jpg', 'sport', 1),
(76, '13.06.2021.', 'Ovo je sport23', 'Ovo je sport2Ovo je sport2Ovo je sport2', 'Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2', 'slika5.jpg', 'sport', 0),
(77, '13.06.2021.', 'Ovo je sport23', 'Ovo je sport2Ovo je sport2Ovo je sport2', 'Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2Ovo je sport2', 'slika5.jpg', 'sport', 1),
(78, '13.06.2021.', 'Ovo je sport4', 'Ovo je sport4Ovo je sport4Ovo je sport4', 'Ovo je sport4Ovo je sport4Ovo je sport4Ovo je sport4v', 'slika4.jpg', 'sport', 1),
(79, '13.06.2021.', 'Ovo je sport4', 'Ovo je sport4Ovo je sport4Ovo je sport4', 'Ovo je sport4Ovo je sport4Ovo je sport4Ovo je sport4v', 'slika4.jpg', 'sport', 0),
(80, '13.06.2021.', 'Ovo je sport4', 'Ovo je sport4Ovo je sport4Ovo je sport4', 'vOvo je sport4Ovo je sport4', 'slika6.jpg', 'sport', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`);

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
