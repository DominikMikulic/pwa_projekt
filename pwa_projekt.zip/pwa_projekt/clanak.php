<!DOCTYPE html>
<html>

  <head>

    <meta charset="utf-8">

    <link rel="stylesheet" media="screen" href="style2.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  </head>
    <body>
        <header>
        <nav>
                <img class="navslika" src="nav1.jpg" alt="">
                <ul>    
                <li> <a href="index.php" class="">Početna</a> </li> 
                    <li> <a href="kategorija.php?id=sport" class="">Sport</a> </li> 
                    <li><a href="kategorija.php?id=kultura" class="">Kultura</a> </li> 
                    <li> <a href="ako_je_admin.php" class="">Administracija</a> </li> 
                    <li><a href="unos.php">Unos</a></li>
                </ul>
                </nav>         
        </header>



        <?php 
        include 'connect.php'; 
        
        define('UPLPATH', 'img/'); 
        $id=$_GET['id'];
        $query = "SELECT * FROM vijesti WHERE id=$id";
        $result = mysqli_query($dbc, $query); 
        $row = mysqli_fetch_array($result);
        ?>


<div id="main">
            <div class="blog">
                <article class="first">
                <?php 
                                   
                                        echo '<h1>' . $row['kategorija'] . '</h1><br><h3>'. $row['naslov'] . '</h3><br><h6>AUTOR:<br>OBJAVLJENO: ' . $row['datum'] . '<br></h6>';
                                        
                                        echo '<img src="' . UPLPATH . $row['slika'] . '">'; 
                                        
                                        echo '<br><br>' . $row['sazetak'] . '<br>' . $row['tekst'] . '<br><br>';

                               


                                    ?>







                </article>
            </div>
        </div>
        <footer>
        
        </footer>
    </body>
</html>
