<!DOCTYPE html>
<html>

  <head>

    <meta charset="utf-8">

    <link rel="stylesheet" media="screen" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  </head>
    <body>
        <header>
        
            <nav>
                <img class="navslika" src="nav1.jpg" alt="">
                <!-- <ul>    
                <li> <a href="index.php" class="">Početna</a> </li> 
                    <li> <a href="kategorija.php?id=sport" class="">Sport</a> </li> 
                    <li><a href="kategorija.php?id=kultura" class="">Kultura</a> </li> 
                    <li> <a href="administracija.php" class="">Administracija</a> </li> 
                    <li><a href="unos.php">Unos</a></li>
                </ul> -->
                </nav>         
        </header>

        <div id="main">
            <div class="blog">
                <div class="main">
                <article class="first">


<form enctype="multipart/form-data" action="registracija.php" method="POST"> 
                    <div class="form-item"> 
                        <span id="porukaIme" class="bojaPoruke"></span> 
                        <label for="title"><br>Ime: </label> 
                        <div class="form-field"> 
                            <input type="text" name="ime" id="ime" class="form-field-textual"> 
                        </div> 
                    </div> 
                    <div class="form-item"> 
                        <span id="porukaPrezime" class="bojaPoruke"></span> 
                        <label for="about"><br>Prezime: </label> 
                        <div class="form-field"> 
                            <input type="text" name="prezime" id="prezime" class="form-field-textual"> 
                        </div> 
                    </div> 
                    <div class="form-item"> 
                        <span id="porukaUsername" class="bojaPoruke"></span> 
                        <label for="content"><br>Korisničko ime:</label> 
                        <div class="form-field"> 
                            <input type="text" name="username" id="username" class="form-field-textual"> 
                        </div> 
                    </div> 
                    <div class="form-item"> 
                        <span id="porukaPass" class="bojaPoruke"></span>
                         <label for="pphoto"><br>Lozinka: </label> 
                         <div class="form-field">
                         <input type="password" name="pass" id="pass" class="form-field-textual"> 
                         </div> 
                         </div> 
                         <div class="form-item"> 
                             <span id="porukaPassRep" class="bojaPoruke"></span> 
                             <label for="pphoto"><br>Ponovite lozinku: </label> 
                             <div class="form-field"> 
                                 <input type="password" name="passRep" id="passRep" class="form-field-textual"> 
                                 </div> 
                                 </div> <br>
                                 <div class="form-item"> 
                                     <button type="submit" value="Prijava" id="slanje">Registracija</button> <br>
                                     </div> <br>
                                     </form> 


                                     </article>                    
                    </div>
            </div>
        </div>


                                     <footer>
        
        </footer>
    </body>
</html>
