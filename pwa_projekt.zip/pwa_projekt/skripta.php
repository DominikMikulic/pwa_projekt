<!DOCTYPE html>
<html>

  <head>

    <meta charset="utf-8">

    <link rel="stylesheet" media="screen" href="style2.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  </head>
    <body>
        <header>
        <nav>
                <img class="navslika" src="nav1.jpg" alt="">
                <ul>    
                <li> <a href="index.php" class="">Početna</a> </li> 
                    <li> <a href="kategorija.php?id=sport" class="">Sport</a> </li> 
                    <li><a href="kategorija.php?id=kultura" class="">Kultura</a> </li> 
                    <li> <a href="ako_je_admin.php" class="">Administracija</a> </li> 
                    <li><a href="unos.php">Unos</a></li>
                </ul>
                </nav>         
        </header>


        <div id="main">
            <div class="blog">
                <article class="first">                     
                                    <?php 
                                    $category=$_POST['category'];
                                    $title=$_POST['title'];
                                    $about=$_POST['about'];
                                    $content=$_POST['content'];
                                    if(isset($_POST['Prihvati'])){
                                        echo '<h1>' . $category . '</h1><br><h3>'. $title . '</h3><br><h6>AUTOR:<br>OBJAVLJENO:<br></h6>';
                                        
                                        $filepath =  $_FILES["pphoto"]["name"];
                                        if(move_uploaded_file($_FILES["pphoto"]["tmp_name"], $filepath)) 
                                        {
                                        echo "<img src=".$filepath."  />";
                                        } 
                                        else 
                                        {
                                        echo "Error !!";
                                        }
                                        
                                        echo '<br><br>' . $about . '<br>' . $content . '<br><br>';
                                    }
                                   include 'insert.php';
                               


                                    ?>








                     </article>
            </div>
        </div>


        <footer>
        
        </footer>
    </body>
</html>